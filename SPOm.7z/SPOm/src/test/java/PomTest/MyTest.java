package PomTest;

	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.chrome.ChromeDriver;
	import org.testng.annotations.Test;

import Pages.Login;

	public class MyTest {
		@Test
		public void validateLogin()
		{
			System.setProperty("webdriver.chrome.driver","C:/BDD699/SPOm/src/test/java/chromedriver.exe");
			WebDriver driver = new ChromeDriver();
			driver.manage().window().maximize();
			driver.get("http://demosite.center/wordpress/wp-login.php");
			Login login = new Login(driver);
			login.typeUserName();
			login.typePassword();
			login.typeLoginButton();
			//driver.quit();
		}
	}




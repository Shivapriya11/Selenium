package StepDefination;
import org.junit.Assert;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
public class StepDefination {
	public class palindrome {
	    String testpal;
	    boolean ispal;
	    
	    @Given("I entered string {string}")
	    public void i_entered_string(String test) throws Throwable {
	       testpal=test;
	    }

	
	    @When("I test it for palindrome")
	    public void i_test_it_for_palindrome() throws Throwable {
	      ispal=testpal.equalsIgnoreCase(new StringBuilder(testpal).reverse().toString());
	    }

	 
	    @Then("the result should be{string}")
	    public void the_result_should_be(String s) throws Throwable {
	       boolean estRes=Boolean.parseBoolean(s);
	       if(estRes) {
	           Assert.assertTrue(ispal);
	       }
	       else {
	           Assert.assertTrue(ispal);
	       }
	    }

	
	}
	 
}
